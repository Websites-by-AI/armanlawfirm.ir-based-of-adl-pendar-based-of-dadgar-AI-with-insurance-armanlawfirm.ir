import React, { useState } from 'react';
import { useLanguage, PageKey } from '../types';

interface MapFinderProps {
    setPage: (page: 'home' | PageKey) => void;
}

const MapFinder: React.FC<MapFinderProps> = ({ setPage }) => {
    const { t } = useLanguage();
    const [isLoading, setIsLoading] = useState(true);
    
    const externalMapUrl = 'https://fbf5c9fb-bd5c-48f5-a87f-30402730e13f-00-2zfa03n8n0o8d.sisko.replit.dev/';

    return (
        <div className="min-h-screen bg-gray-50 dark:bg-[#111827] transition-colors animate-fade-in">
            <div className="container mx-auto px-4 py-8">
                <div className="mb-8">
                    <button 
                        onClick={() => setPage('home')}
                        className="flex items-center gap-2 text-gray-600 dark:text-gray-400 hover:text-brand-gold transition-colors mb-4"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z" clipRule="evenodd" />
                        </svg>
                        <span>بازگشت به صفحه اصلی</span>
                    </button>
                    
                    <div className="text-center">
                        <div className="inline-flex items-center px-4 py-2 rounded-full bg-brand-gold/10 border border-brand-gold/30 text-brand-gold text-sm font-semibold mb-4">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" viewBox="0 0 20 20" fill="currentColor">
                                <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
                            </svg>
                            نقشه یاب هوشمند
                        </div>
                        <h1 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
                            یافتن <span className="text-brand-gold">دفاتر حقوقی</span> در نقشه
                        </h1>
                        <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
                            با استفاده از نقشه هوشمند، نزدیک‌ترین دفاتر حقوقی، دفاتر اسناد رسمی و مراکز قضایی را در محل خود پیدا کنید.
                        </p>
                    </div>
                </div>

                <div className="bg-white dark:bg-[#1F1F1F] rounded-2xl border border-gray-200 dark:border-gray-800 shadow-xl overflow-hidden">
                    <div className="bg-gradient-to-r from-brand-blue to-gray-900 p-4 flex items-center justify-between">
                        <div className="flex items-center gap-3">
                            <div className="w-3 h-3 rounded-full bg-red-500"></div>
                            <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                            <div className="w-3 h-3 rounded-full bg-green-500"></div>
                        </div>
                        <div className="flex items-center gap-2 text-white/70 text-sm">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                                <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
                            </svg>
                            <span>اتصال امن</span>
                        </div>
                    </div>
                    
                    <div className="relative" style={{ minHeight: '600px' }}>
                        {isLoading && (
                            <div className="absolute inset-0 flex items-center justify-center bg-gray-100 dark:bg-gray-800 z-10">
                                <div className="text-center">
                                    <div className="w-16 h-16 border-4 border-brand-gold/30 border-t-brand-gold rounded-full animate-spin mx-auto mb-4"></div>
                                    <p className="text-gray-600 dark:text-gray-400">در حال بارگذاری نقشه...</p>
                                </div>
                            </div>
                        )}
                        <iframe 
                            src={externalMapUrl}
                            className="w-full border-0"
                            style={{ height: '600px' }}
                            title="نقشه یاب حقوقی"
                            onLoad={() => setIsLoading(false)}
                            allow="geolocation"
                        />
                    </div>
                </div>

                <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="bg-white dark:bg-[#1F1F1F] p-6 rounded-xl border border-gray-200 dark:border-gray-800 hover:border-brand-gold/50 transition-colors">
                        <div className="w-12 h-12 bg-brand-gold/10 rounded-xl flex items-center justify-center mb-4">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-brand-gold" viewBox="0 0 20 20" fill="currentColor">
                                <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
                            </svg>
                        </div>
                        <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">موقعیت‌یابی دقیق</h3>
                        <p className="text-gray-600 dark:text-gray-400 text-sm">مکان دقیق دفاتر حقوقی را با استفاده از GPS پیدا کنید</p>
                    </div>
                    
                    <div className="bg-white dark:bg-[#1F1F1F] p-6 rounded-xl border border-gray-200 dark:border-gray-800 hover:border-brand-gold/50 transition-colors">
                        <div className="w-12 h-12 bg-brand-gold/10 rounded-xl flex items-center justify-center mb-4">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-brand-gold" viewBox="0 0 20 20" fill="currentColor">
                                <path d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z" />
                            </svg>
                        </div>
                        <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">وکلای مجرب</h3>
                        <p className="text-gray-600 dark:text-gray-400 text-sm">دسترسی به اطلاعات تماس وکلای پایه یک دادگستری</p>
                    </div>
                    
                    <div className="bg-white dark:bg-[#1F1F1F] p-6 rounded-xl border border-gray-200 dark:border-gray-800 hover:border-brand-gold/50 transition-colors">
                        <div className="w-12 h-12 bg-brand-gold/10 rounded-xl flex items-center justify-center mb-4">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-brand-gold" viewBox="0 0 20 20" fill="currentColor">
                                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
                            </svg>
                        </div>
                        <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">ساعات کاری</h3>
                        <p className="text-gray-600 dark:text-gray-400 text-sm">مشاهده ساعات کاری و وضعیت فعلی دفاتر</p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default MapFinder;
